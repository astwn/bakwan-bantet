// document.addEventListener("DOMContentLoaded", function (event) {
//     window.addEventListener("load", function () {
//         const mount = () => {
//             new Splide("#slider1").mount();
//             new Splide("#slider2").mount();
//         };

//         function delay() {
//             setTimeout(function () {
//                 mount();
//             }, 200);
//         }

//         if (document.readyState == "complete") {
//             delay();
//         } else {
//             document.onreadystatechange = function () {
//                 if (document.readyState === "complete") {
//                     delay();
//                 }
//             };
//         }
//     });
// });
