-- AlterTable
ALTER TABLE "User" ADD COLUMN     "accountIsVerified" BOOLEAN NOT NULL DEFAULT false;
