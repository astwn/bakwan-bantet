-- AlterTable
ALTER TABLE "Rooms_Records" ADD COLUMN     "isSuccess" BOOLEAN NOT NULL DEFAULT false;
