-- AlterTable
ALTER TABLE "Card" ADD COLUMN     "isTwoStepAuth" BOOLEAN NOT NULL DEFAULT true;
