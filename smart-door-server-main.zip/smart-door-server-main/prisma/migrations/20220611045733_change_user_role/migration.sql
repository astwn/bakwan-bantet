-- DropIndex
DROP INDEX "User_roleId_key";
