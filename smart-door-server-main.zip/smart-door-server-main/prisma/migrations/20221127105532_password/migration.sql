-- AlterTable
ALTER TABLE "User" ALTER COLUMN "passwordUpdatedAt" DROP DEFAULT;
