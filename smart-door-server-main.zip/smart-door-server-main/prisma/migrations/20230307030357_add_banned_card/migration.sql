-- AlterTable
ALTER TABLE "Card" ADD COLUMN     "banned" BOOLEAN NOT NULL DEFAULT false;
