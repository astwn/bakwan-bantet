-- AlterTable
ALTER TABLE "User" ADD COLUMN     "passwordUpdatedAt" TIMESTAMP(3);
