-- CreateTable
CREATE TABLE "Api_Key" (
    "id" TEXT NOT NULL,
    "secret" TEXT NOT NULL,

    CONSTRAINT "Api_Key_pkey" PRIMARY KEY ("id")
);
