-- AlterTable
ALTER TABLE "Device" ALTER COLUMN "roomId" DROP NOT NULL;
