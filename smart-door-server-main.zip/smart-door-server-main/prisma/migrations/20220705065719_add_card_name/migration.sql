-- AlterTable
ALTER TABLE "Card" ADD COLUMN     "card_name" TEXT;
