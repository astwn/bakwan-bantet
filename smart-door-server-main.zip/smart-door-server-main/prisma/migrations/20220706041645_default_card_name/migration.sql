-- AlterTable
ALTER TABLE "Card" ALTER COLUMN "card_name" SET DEFAULT E'Kartu Saya';
