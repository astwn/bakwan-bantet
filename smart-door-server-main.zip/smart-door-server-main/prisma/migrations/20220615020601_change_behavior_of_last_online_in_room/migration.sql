-- AlterTable
ALTER TABLE "Room" ALTER COLUMN "lastOnline" DROP NOT NULL;
