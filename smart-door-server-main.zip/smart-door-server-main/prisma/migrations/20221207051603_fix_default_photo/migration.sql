-- AlterTable
ALTER TABLE "Profil" ALTER COLUMN "photo" SET DEFAULT '/image/illustration-user.png';
